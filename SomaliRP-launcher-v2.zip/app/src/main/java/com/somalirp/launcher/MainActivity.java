package com.somalirp.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.util.zip.*;

public class MainActivity extends Activity {
    // ===== EDIT THESE =====
    static final String SERVER_NAME = "SOMALI ROELPLAY";
    static final String SERVER_IP = "51.254.178.238";
    static final int SERVER_PORT = 7777;
    static final String GAME_ID = "";      // game package ID
    static final String GAME_URL = "";     // link of the game zip file (host link)
    static final String DISCORD = "https://discord.com";
    static final String INSTAGRAM = "https://instagram.com";
    static final String WEBSITE = "https://example.com";
    static final String APP_LINK = "https://example.com";
    // ======================

    SharedPreferences sp;
    FrameLayout main, upd, load;
    EditText name;
    Button action, musicBtn;
    TextView online, players, srv, updLeft, updRight, updPct;
    ProgressBar bar;
    LinearLayout playersCard;
    Button settings;
    MediaPlayer mp;
    Handler h = new Handler();

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(r)); return g;
    }

    TextView tv(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }

    ImageView logo(int size) {
        ImageView l = new ImageView(this);
        l.setImageResource(R.drawable.logo);
        l.setScaleType(ImageView.ScaleType.FIT_CENTER);
        l.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return l;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("srp", MODE_PRIVATE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.bg);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View dim = new View(this);
        dim.setBackgroundColor(0xAA000000);
        root.addView(dim, new FrameLayout.LayoutParams(-1, -1));

        main = buildMain();
        upd = buildUpdate();
        load = buildLoading();
        root.addView(main, new FrameLayout.LayoutParams(-1, -1));
        root.addView(upd, new FrameLayout.LayoutParams(-1, -1));
        root.addView(load, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        show(main);
        refreshState();
    }

    void show(FrameLayout f) {
        main.setVisibility(f == main ? View.VISIBLE : View.GONE);
        upd.setVisibility(f == upd ? View.VISIBLE : View.GONE);
        load.setVisibility(f == load ? View.VISIBLE : View.GONE);
    }

    // ---------- MAIN SCREEN ----------
    FrameLayout buildMain() {
        FrameLayout f = new FrameLayout(this);
        ImageView lg = new ImageView(this);
        lg.setImageResource(R.drawable.logo);
        f.addView(lg, new FrameLayout.LayoutParams(dp(230), dp(230), Gravity.CENTER));

        name = new EditText(this);
        name.setHint("Magacaaga");
        name.setHintTextColor(0x99FFFFFF);
        name.setTextColor(Color.WHITE);
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT);
        name.setText(sp.getString("name", ""));
        name.setBackground(round(0xAA1B1B1B, 14));
        name.setPadding(dp(16), dp(10), dp(16), dp(10));
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(dp(220), -2, Gravity.TOP | Gravity.START);
        nlp.setMargins(dp(16), dp(16), 0, 0);
        f.addView(name, nlp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        online = tv("", 15, Color.WHITE);
        online.setPadding(dp(16), dp(10), dp(16), dp(10));
        online.setBackground(round(0xAA1B1B1B, 14));
        online.setVisibility(View.GONE);
        settings = new Button(this);
        settings.setText("\u2699");
        settings.setTextColor(Color.WHITE);
        settings.setBackground(round(0xAA1B1B1B, 14));
        settings.setVisibility(View.GONE);
        settings.setOnClickListener(v -> toast("Settings"));
        top.addView(settings, new LinearLayout.LayoutParams(dp(48), dp(44)));
        top.addView(online);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        tlp.setMargins(0, dp(16), dp(16), 0);
        f.addView(top, tlp);

        LinearLayout soc = new LinearLayout(this);
        soc.setPadding(dp(8), dp(8), dp(8), dp(8));
        soc.setBackground(round(0xAA1B1B1B, 14));
        String[][] s = {{"Discord", DISCORD}, {"Instagram", INSTAGRAM}, {"Website", WEBSITE}, {"App", APP_LINK}};
        for (String[] x : s) {
            Button t = new Button(this);
            t.setText(x[0]); t.setTextColor(Color.WHITE); t.setAllCaps(false); t.setTextSize(12);
            t.setBackground(round(0x33FFFFFF, 10));
            t.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(x[1]))));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(40));
            p.setMargins(dp(4), 0, dp(4), 0);
            soc.addView(t, p);
        }
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        slp.setMargins(dp(16), 0, 0, dp(16));
        f.addView(soc, slp);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        playersCard = new LinearLayout(this);
        playersCard.setOrientation(LinearLayout.VERTICAL);
        playersCard.setPadding(dp(16), dp(12), dp(16), dp(12));
        playersCard.setBackground(round(0xAA1B1B1B, 14));
        srv = tv(SERVER_NAME, 16, Color.WHITE);
        srv.setTypeface(null, Typeface.BOLD);
        players = tv("...", 20, Color.WHITE);
        playersCard.addView(srv);
        playersCard.addView(players);
        playersCard.setVisibility(View.GONE);
        right.addView(playersCard, new LinearLayout.LayoutParams(-1, -2));
        action = new Button(this);
        action.setTextColor(Color.WHITE); action.setTextSize(20);
        action.setTypeface(null, Typeface.BOLD);
        action.setBackground(round(0xFFF28C00, 18));
        action.setOnClickListener(v -> onAction());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(56));
        ap.setMargins(0, dp(10), 0, 0);
        right.addView(action, ap);
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(dp(300), -2, Gravity.BOTTOM | Gravity.END);
        rlp.setMargins(0, 0, dp(16), dp(16));
        f.addView(right, rlp);
        return f;
    }

    // ---------- UPDATE SCREEN ----------
    FrameLayout buildUpdate() {
        FrameLayout f = new FrameLayout(this);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(logo(200));
        TextView title = tv("Cusboonaysiinta faylasha", 16, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, dp(8), 0, dp(6));
        c.addView(title);
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        c.addView(bar, new LinearLayout.LayoutParams(dp(460), dp(8)));
        LinearLayout row = new LinearLayout(this);
        updLeft = tv("", 12, 0xFFCCCCCC);
        updRight = tv("", 12, Color.WHITE);
        row.addView(updLeft, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(updRight);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(460), -2);
        rp.setMargins(0, dp(8), 0, 0);
        c.addView(row, rp);
        f.addView(c, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        return f;
    }

    // ---------- LOADING SCREEN ----------
    FrameLayout buildLoading() {
        FrameLayout f = new FrameLayout(this);
        ImageView lg = new ImageView(this);
        lg.setImageResource(R.drawable.logo);
        f.addView(lg, new FrameLayout.LayoutParams(dp(260), dp(260), Gravity.CENTER));
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(8));
        box.setBackground(round(0xCC000000, 12));
        musicBtn = new Button(this);
        musicBtn.setText("\u275A\u275A");
        musicBtn.setTextColor(Color.WHITE);
        musicBtn.setBackground(round(0x33FFFFFF, 10));
        musicBtn.setOnClickListener(v -> toggleMusic());
        box.addView(musicBtn, new LinearLayout.LayoutParams(dp(44), dp(40)));
        TextView t = tv("  Waa la rarayaa...", 14, Color.WHITE);
        box.addView(t);
        ProgressBar sp2 = new ProgressBar(this);
        box.addView(sp2, new LinearLayout.LayoutParams(dp(28), dp(28)));
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        blp.setMargins(0, 0, dp(16), dp(16));
        f.addView(box, blp);
        return f;
    }

    boolean installed() { return sp.getBoolean("installed", false); }

    void refreshState() {
        if (installed()) {
            action.setText("BILOW");
            settings.setVisibility(View.VISIBLE);
            playersCard.setVisibility(View.VISIBLE);
            online.setVisibility(View.VISIBLE);
            players.setText("...");
            queryPlayers();
        } else {
            action.setText("CUSBOONAYSI");
            settings.setVisibility(View.GONE);
            playersCard.setVisibility(View.GONE);
            online.setVisibility(View.GONE);
        }
    }

    void onAction() {
        sp.edit().putString("name", name.getText().toString().trim()).apply();
        if (installed()) play(); else update();
    }

    void play() {
        if (GAME_ID.isEmpty()) { toast("Game ID ma jiro"); return; }
        show(load);
        startMusic();
        h.postDelayed(() -> {
            Intent i = getPackageManager().getLaunchIntentForPackage(GAME_ID);
            if (i == null) { stopMusic(); show(main); toast("Ciyaarta lama helin"); return; }
            startActivity(i);
        }, 8000);
    }

    void update() {
        if (GAME_URL.isEmpty()) { toast("Link-ga ciyaarta ma jiro"); return; }
        show(upd);
        bar.setProgress(0);
        updLeft.setText("Soo dejinaya...");
        updRight.setText("");
        new Thread(() -> {
            try {
                File dir = new File(getExternalFilesDir(null), "game");
                dir.mkdirs();
                File zip = new File(getCacheDir(), "game.zip");
                HttpURLConnection c = (HttpURLConnection) new URL(GAME_URL).openConnection();
                final long len = c.getContentLengthLong();
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(zip)) {
                    byte[] buf = new byte[65536]; int n; long tot = 0;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n); tot += n;
                        final long t = tot;
                        runOnUiThread(() -> {
                            if (len > 0) bar.setProgress((int) (t * 70 / len));
                            updRight.setText((t / 1048576) + " MB / " + (len > 0 ? (len / 1048576) : "?") + " MB");
                        });
                    }
                }
                ZipFile zf = new ZipFile(zip);
                final int total = zf.size();
                int k = 0;
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    k++;
                    final int kk = k;
                    runOnUiThread(() -> {
                        bar.setProgress(70 + kk * 30 / Math.max(1, total));
                        updLeft.setText("Faylasha: " + kk + " / " + total);
                    });
                    File f = new File(dir, e.getName());
                    if (!f.getCanonicalPath().startsWith(dir.getCanonicalPath())) continue;
                    if (e.isDirectory()) { f.mkdirs(); continue; }
                    f.getParentFile().mkdirs();
                    try (InputStream in = zf.getInputStream(e); OutputStream o = new FileOutputStream(f)) {
                        byte[] buf = new byte[65536]; int n;
                        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                    }
                }
                zf.close();
                zip.delete();
                sp.edit().putBoolean("installed", true).apply();
                runOnUiThread(() -> { show(main); refreshState(); });
            } catch (Exception ex) {
                runOnUiThread(() -> { show(main); toast("Khalad: " + ex.getMessage()); });
            }
        }).start();
    }

    void queryPlayers() {
        new Thread(() -> {
            String txt = "-";
            try (DatagramSocket s = new DatagramSocket()) {
                s.setSoTimeout(2500);
                String[] ip = SERVER_IP.split("\\.");
                byte[] q = new byte[11];
                q[0] = 'S'; q[1] = 'A'; q[2] = 'M'; q[3] = 'P';
                for (int i = 0; i < 4; i++) q[4 + i] = (byte) Integer.parseInt(ip[i]);
                q[8] = (byte) (SERVER_PORT & 0xFF); q[9] = (byte) ((SERVER_PORT >> 8) & 0xFF); q[10] = 'i';
                s.send(new DatagramPacket(q, q.length, InetAddress.getByName(SERVER_IP), SERVER_PORT));
                byte[] r = new byte[512];
                s.receive(new DatagramPacket(r, r.length));
                int pl = (r[12] & 0xFF) | ((r[13] & 0xFF) << 8);
                int mx = (r[14] & 0xFF) | ((r[15] & 0xFF) << 8);
                txt = pl + "/" + mx;
            } catch (Exception ignored) { }
            final String t = txt;
            runOnUiThread(() -> { players.setText(t); online.setText(t + "  ONLINE"); });
        }).start();
    }

    void startMusic() {
        if (mp != null) return;
        mp = MediaPlayer.create(this, R.raw.music);
        if (mp != null) { mp.setLooping(true); mp.start(); musicBtn.setText("\u275A\u275A"); }
    }

    void toggleMusic() {
        if (mp == null) return;
        if (mp.isPlaying()) { mp.pause(); musicBtn.setText("\u25B6"); }
        else { mp.start(); musicBtn.setText("\u275A\u275A"); }
    }

    void stopMusic() {
        if (mp != null) { try { mp.stop(); mp.release(); } catch (Exception ignored) { } mp = null; }
    }

    @Override protected void onPause() { super.onPause(); h.removeCallbacksAndMessages(null); stopMusic(); }
    @Override protected void onResume() {
        super.onResume();
        if (load.getVisibility() == View.VISIBLE) { show(main); }
        if (upd.getVisibility() != View.VISIBLE) refreshState();
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }
}
